package JiaoGuTheory;

import java.util.Scanner;

public class �ݹ� {
	static int sum=0;
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("������һ����Ȼ����");
		int x=sc.nextInt();
		sc.close();
		int sum=one(x);
		System.out.println();
		System.out.println("һ��������"+sum+"��");
		
	}
	
	public static int one(int x)
	{
		if(x==1)
		{
			System.out.print(x+" ");
			sum++;
		}
		else if(x%2==0)
		{
			System.out.print(x+" ");
			one(x/2);
			sum++;
		}
		else if(x%2!=0)
		{
			System.out.print(x+" ");
			one(x*3+1);
			sum++;
		}
		return sum;
	}
}

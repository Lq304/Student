package DuckSale;

public class �ǵݹ� {

}
